<?php
    session_start();

    $helper = array_keys($_SESSION);
    foreach ($helper as $key){
        unset($_SESSION[$key]);
    }
header('location:https://gnb09.blogspot.co.id/');
?>